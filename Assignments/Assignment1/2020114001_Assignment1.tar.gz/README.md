---
title: Operating Systems and Networks (CS3.301)
subtitle: |
          | Monsoon 2022, IIIT Hyderabad
          | Assignment 1
author: |
        | Abhinav S Menon
        | (2020114001)
---

# Assumptions
Throughout the assignment, it has been assumed that all file paths given as command-line arguments are **relative to the cwd**.

In part 2, it is assumed that
$$0 \leq s \leq e \leq l,$$
where $s =$ `start_idx`, $e =$ `end_idx`, and $l =$ `file_length`.
